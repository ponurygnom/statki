package com.example.shakedogshake;
import static androidx.activity.EdgeToEdge.*;
import static androidx.core.view.ViewCompat.*;
import static androidx.core.view.WindowInsetsCompat.Type.*;
import static com.google.android.material.R.drawable.abc_star_black_48dp;
import static java.lang.System.*;
import static java.util.Arrays.*;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import java.util.Random;
public class MainActivity extends AppCompatActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        enable(this);
        setContentView(R.layout.activity_main);
        setOnApplyWindowInsetsListener(this.<View>findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        LinearLayout lejałt = findViewById(R.id.linearLayout);
        LinearLayout lejałt2 = findViewById(R.id.linearLayout2);
        LinearLayout lejałt3 = findViewById(R.id.linearLayout3);
        LinearLayout lejałt4 = findViewById(R.id.linearLayout4);
        LinearLayout lejałt5 = findViewById(R.id.linearLayout5);
        LinearLayout lejałt6 = findViewById(R.id.linearLayout6);
        LinearLayout lejałt7 = findViewById(R.id.linearLayout7);
        LinearLayout lejałt8 = findViewById(R.id.linearLayout8);
        LinearLayout lejałt9 = findViewById(R.id.linearLayout9);
        ImageButton button = findViewById(R.id.imageButton);
        ImageButton button2 = findViewById(R.id.imageButton2);
        ImageButton button3 = findViewById(R.id.imageButton3);
        ImageButton button4 = findViewById(R.id.imageButton4);
        ImageButton button5 = findViewById(R.id.imageButton5);
        asList(new LinearLayout[]{lejałt, lejałt2, lejałt3, lejałt4, lejałt5,lejałt6,lejałt7,lejałt8,lejałt9}).forEach(linearLayout -> linearLayout.setEnabled(false));
        Random r;
        r = new Random();
        int i;
        do {
            i = r.nextInt(9);
        } while (i > 9);
        if(r.nextInt()<=9){
            switch (i){
                case 0:
                    out.println("ŁAJ KANT AJ BI JU");
                    break;
                case 1: lejałt.setEnabled(true);
                    break;
                case 2: lejałt2.setEnabled(true);
                    break;
                case 3: lejałt3.setEnabled(true);
                    break;
                case 4: lejałt4.setEnabled(true);
                    break;
                case 5: lejałt5.setEnabled(true);
                    break;
                case 6: lejałt6.setEnabled(true);
                    break;
                case 7: lejałt7.setEnabled(true);
                    break;
                case 8: lejałt8.setEnabled(true);
                    break;
                case 9: lejałt9.setEnabled(true);
                    break;
                default:
                    throw new IllegalStateException("Unexpected value: " + i);
            }
        }
        //it's no secret that the stars are falling from the sy
        button.setOnClickListener(v -> button.setImageResource(abc_star_black_48dp));
        button2.setOnClickListener(v -> button2.setImageResource(abc_star_black_48dp));
        button3.setOnClickListener(v -> button3.setImageResource(abc_star_black_48dp));
        button4.setOnClickListener(v -> button4.setImageResource(abc_star_black_48dp));
        button5.setOnClickListener(v -> button5.setImageResource(abc_star_black_48dp));
    }
}